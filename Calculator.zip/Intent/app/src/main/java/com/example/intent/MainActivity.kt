package com.example.intent

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    var lastNumeric = true
    var lastDot = false
    var firstNum: Int? = null
    var secondNum: Int? = null
    var firstNumAdded = false
    var operator: String? = null
    lateinit var numberScreen : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        numberScreen = findViewById(R.id.numberScreen)

    }

    fun onDigit(view : View) {
        numberScreen.append((view as Button).text)
    }
    fun onCLR(view : View) {
        numberScreen.text = ""
    }
    fun onDecimal(view : View) {
        if (lastNumeric && !lastDot) {
            numberScreen.append(".")
            lastNumeric = false
            lastDot = true
        }
    }
    fun onMulti(view : View) {
        firstNum = numberScreen.text.toString().toInt()
        operator = "*"
        numberScreen.append("*")
    }
    fun onDiv(view : View) {
        firstNum = numberScreen.text.toString().toInt()
        operator = "/"
        numberScreen.append("/")
    }
    fun onPlus(view : View) {
        firstNum = numberScreen.text.toString().toInt()
        operator = "+"
        numberScreen.append("+")
    }
    fun onMinus(view : View) {
        firstNum = numberScreen.text.toString().toInt()
        operator = "-"
        numberScreen.append("-")
    }
    fun onMod(view : View) {
        firstNum = numberScreen.text.toString().toInt()
        operator = "%"
        numberScreen.append("%")
    }
    fun onEqual(view : View ) {
        secondNum = operator?.let { numberScreen.text.toString().substringAfter(it).toInt() }
        if (operator == "+") {
            numberScreen.text = (firstNum?.plus(secondNum!!)).toString()
        }
        else if(operator == "-") {
            numberScreen.text = (firstNum?.minus(secondNum!!)).toString()
        }
        else if(operator == "/") {
            numberScreen.text = (firstNum?.toFloat()?.div(secondNum!!)?.toFloat()).toString()
        }
        else if(operator == "*") {
            numberScreen.text = (firstNum?.times(secondNum!!)).toString()
        }
        else {
            numberScreen.text = (firstNum?.rem((secondNum!!))).toString()
        }
        firstNum = null
        secondNum = null
        operator = null
    }

}


